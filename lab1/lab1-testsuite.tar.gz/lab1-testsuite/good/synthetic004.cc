a::b::c::q xxx = "fpp!" < "gazoook";
