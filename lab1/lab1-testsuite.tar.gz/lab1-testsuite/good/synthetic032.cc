int main () {
  char c = 'a';
  return ord(c);
}
