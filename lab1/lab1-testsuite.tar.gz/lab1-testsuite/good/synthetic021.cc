// vector is not a built-in type, it's an identifier
int vector = 2;
