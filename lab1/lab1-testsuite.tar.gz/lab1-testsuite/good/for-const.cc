int main() {
  for (const int i = 0; i != 100; ++i)
    i = i;
}
