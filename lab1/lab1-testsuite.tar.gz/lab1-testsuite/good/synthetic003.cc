int xx, x, y, q;
