int a = 0, b = 1;
int c, d = 2;
int e = 3, f;

int main() {
  int a = 0, b = 1;
  int c, d = 2;
  int e = 3, f;
}
