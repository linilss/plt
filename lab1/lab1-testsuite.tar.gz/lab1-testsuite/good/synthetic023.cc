int x = 4;
int y = x += 2;
