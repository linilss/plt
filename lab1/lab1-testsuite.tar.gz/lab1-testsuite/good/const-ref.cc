int main() {
  const int& x;
}
