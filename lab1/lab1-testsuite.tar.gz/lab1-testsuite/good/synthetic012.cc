int main() {
	double x = 5.00e10;
	return 0;
}
