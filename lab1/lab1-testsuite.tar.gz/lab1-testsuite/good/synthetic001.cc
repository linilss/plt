typedef a::b::c::q foo;
