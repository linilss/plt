int main () {
	for ((3%x) y; 1; 3) {}
}
