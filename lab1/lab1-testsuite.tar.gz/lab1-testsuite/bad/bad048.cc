void foo(int x&) {

}
