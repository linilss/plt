int main () {
	do {int x = 1; } int x;
}
