void foo(int double) {

}
