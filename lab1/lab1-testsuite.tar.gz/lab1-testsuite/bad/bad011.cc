int , x;
