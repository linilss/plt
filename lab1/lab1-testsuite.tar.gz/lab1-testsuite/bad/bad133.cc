int main() {
	const int & + 1;
}
