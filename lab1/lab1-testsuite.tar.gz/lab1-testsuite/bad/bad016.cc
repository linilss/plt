typedef <foo> apa;
