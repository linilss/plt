int main((const int x) = 1) {
}
