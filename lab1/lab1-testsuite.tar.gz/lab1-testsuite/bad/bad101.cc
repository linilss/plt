int main () {
	1 + int;
}
