using void::foo;
