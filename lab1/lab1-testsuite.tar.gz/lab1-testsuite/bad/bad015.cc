typedef <foo>;
