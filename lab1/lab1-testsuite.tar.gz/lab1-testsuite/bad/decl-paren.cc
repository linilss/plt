((const int foo = 0));
