int main() {
	while int x;
}
