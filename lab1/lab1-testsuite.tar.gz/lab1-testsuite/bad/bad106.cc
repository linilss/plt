vector<typedef> foo () {}
