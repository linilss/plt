int foo() {
	do do; while (foo);
}
