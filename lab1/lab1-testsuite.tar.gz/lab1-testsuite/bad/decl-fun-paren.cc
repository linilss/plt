int fun((int foo = 4), int foo = 4);
