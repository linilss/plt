void foo(const int const) {

}
