int main() {
	do { int x = 1; } for (int x = 1; x != 5; x++) { }
}
