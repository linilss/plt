void bar() {
	
	do 45; while 0;

}
