foo<int>::(2);
