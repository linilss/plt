void foo(const const int x) {

}
