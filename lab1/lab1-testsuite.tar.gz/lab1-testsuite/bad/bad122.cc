int main() {
	do { int x = 1; } if (4 == 5) {}
}
