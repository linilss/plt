int main () {
	do {int x = 1; } return 0
}
