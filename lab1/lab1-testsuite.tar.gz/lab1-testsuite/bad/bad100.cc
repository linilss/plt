int main () {
	1 + void;
}
