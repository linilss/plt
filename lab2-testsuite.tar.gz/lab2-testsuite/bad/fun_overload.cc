void u() {}
void u(int u) {}
int main() { return 0; }
