void arg(void par) { }

int main() {
  return 0;
}
