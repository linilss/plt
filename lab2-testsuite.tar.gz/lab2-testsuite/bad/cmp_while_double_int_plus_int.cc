int main () {
	while (5.324 >= 1 + 43) {}
	return 0;
}
