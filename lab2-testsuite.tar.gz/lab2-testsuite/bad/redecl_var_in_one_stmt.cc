int main() {
  int x, x;
  return 0;
}
