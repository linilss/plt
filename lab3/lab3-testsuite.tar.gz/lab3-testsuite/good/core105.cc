int main() {
  int x = 5;

  while (x > 3) printInt(x--);

  return x;
}
