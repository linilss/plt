int main () {
  if (0 <= 2) bool x0 = true ;
  else 0 ;
  int x0 = 0 ;
  printInt(1);
  return 0;
}
