int main() {
  printInt(24);
  return 0;
}
